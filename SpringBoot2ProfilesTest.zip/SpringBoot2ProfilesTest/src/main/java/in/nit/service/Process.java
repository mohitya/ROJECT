package in.nit.service;

public interface Process {

	public void find();
}
