package in.nit.service.impl;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import in.nit.service.Process;

@Component
@Profile("default")
public class CommonProcess implements Process{

	@Override
	public void find() {
		System.out.println("FROM-DEFAULT");
	}
}




