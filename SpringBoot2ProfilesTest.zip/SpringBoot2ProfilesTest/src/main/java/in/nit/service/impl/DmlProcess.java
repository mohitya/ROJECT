package in.nit.service.impl;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import in.nit.service.Process;
@Component
@Profile("dml")
public class DmlProcess implements Process{

	@Override
	public void find() {
		System.out.println("From-DML");
	}
}




