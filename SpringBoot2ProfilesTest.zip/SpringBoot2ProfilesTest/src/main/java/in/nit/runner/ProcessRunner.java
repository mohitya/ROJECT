package in.nit.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.nit.service.Process;

@Component
public class ProcessRunner implements CommandLineRunner{
	@Autowired
	private Process p;
	@Value("${app.title}")
	private String title;
	@Value("${app.ver}")
	private String version;
	
	@Override
	public void run(String... args) throws Exception {
		System.out.println("-FROM-RUNNER-");
		p.find();
		System.out.println(title+"-----"+version);
	}
}




